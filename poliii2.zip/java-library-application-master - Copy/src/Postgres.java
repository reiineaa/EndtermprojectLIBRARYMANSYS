public class Postgres {
    private String url="jdbc:postgresql://127.0.0.1:5432/postgres";
    private String postgres="postgres";
    private String password="1972";

    public String getUrl() {
        return url;
    }

    public String getPostgres() {
        return postgres;
    }

    public String getPassword() {
        return password;
    }
}
